% data yukleniyor
load prodoftwo.mat;

DFT_prodoftwo = fft2(prodoftwo);

% orijinal sinyal gosterimi
figure;
subplot(2, 2, 1);
imagesc(abs(prodoftwo));
title('Original Signal');

% dft nin genlik spektrumu
subplot(2, 2, 2);
imagesc(abs(DFT_prodoftwo));
title('DFT Magnitude Spectrum');

% ayrıstirilacak bileşenler icin ilklendirme yapılıyor
recovered_components = zeros(size(prodoftwo, 1), size(prodoftwo, 2), 2);

for i = 1:2
    % peak noktalari
    [maxVal, maxIdx] = max(abs(DFT_prodoftwo(:)));
    [rowIdx, colIdx] = ind2sub(size(DFT_prodoftwo), maxIdx);

    % bilesenleri ayristirma
    component = ifft2(DFT_prodoftwo .* (abs(DFT_prodoftwo) == maxVal));
    recovered_components(:, :, i) = component;

    % bilesenlerin gosterimi
    subplot(2, 2, i + 2);
    imagesc(abs(component));
    title(['Recovered Component ', num2str(i)]);

    % ayristrilan bilesini cikart, sinyalden diger bileseni bul 
    DFT_prodoftwo(rowIdx, colIdx) = 0;
end
