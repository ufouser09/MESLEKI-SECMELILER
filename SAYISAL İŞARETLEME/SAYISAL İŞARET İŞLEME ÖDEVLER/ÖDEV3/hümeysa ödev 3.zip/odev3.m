% Veriyi yükle
load sumofthree.mat

% Fourier dönüşümünü al
X = fft2(sumofthree);

% Spektral analiz yaparak önemli frekans bileşenlerini belirle
spectrum = abs(X);
threshold = 0.1 * max(spectrum(:)); % Örnek eşik değeri
important_freqs = spectrum > threshold;

% Spektral analiz sonucunu görselleştir (isteğe bağlı)
figure;
imagesc(log10(spectrum)); % Logaritmik ölçekte görselleştirme
title('Spektral Analiz');

% Kritik frekanslara göre sinyali böl
X1 = X .* (important_freqs & (1:256 <= 64));
X2 = X .* (important_freqs & (1:256 > 64 & 1:256 <= 128));
X3 = X .* (important_freqs & (1:256 > 128)); 

% Ters DFT ile mekansal alan sinyallerini geri kazan
signal1 = ifft2(X1);
signal2 = ifft2(X2);
signal3 = ifft2(X3);

% Sonuçları göster
figure;
subplot(2,2,1);
imagesc(sumofthree); 
title('Orjinal Toplam Sinyal');

subplot(2,2,2);
imagesc(abs(signal1)); 
title('Kazanılan Sinyal 1');

subplot(2,2,3);
imagesc(abs(signal2)); 
title('Kazanılan Sinyal 2');

subplot(2,2,4);
imagesc(abs(signal3)); 
title('Kazanılan Sinyal 3');
